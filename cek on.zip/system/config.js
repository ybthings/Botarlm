//================================//
// Main
//================================//
import { loadDb } from "../database.js";

// Muat database
const db = loadDb();

// Prefix bot
global.prefa = ['', '!', '.', ',', '🐤', '🗿'];

// Nomor owner
global.owner = ['6282147570157'];

// Cooldown command
global.cd = '300'; // 300 detik cooldown

// Link owner
global.linkOwner = "https://wa.me/6283163221894";

// Default code (akan auto-update kalau ada perubahan di database)
global.code = db.settings.code || "code";

// Default image code
global.imgCode = { 
  url: db.settings.imgCodeUrl || 'https://raw.githubusercontent.com/ybthings/Pwsc/refs/heads/main/file_00000000ece461f98597f1297d6d24a6.png' 
};

// Default KTP image
global.ktpCode = { 
  url: db.settings.ktpUrl || '' 
};

//================================//
// Global Mess
//================================//
global.menuMode = global.menuMode || {};
global.mess = {
  owner: '*You are not the owner*',
  premium: '*You are not premium*',
  group: '*This feature is for groups only*'
};

//================================//
// Auto Refresh Global Variables
//================================//
export function refreshGlobals() {
  const newDb = loadDb();
  global.code = newDb.settings.code || "code";
  global.imgCode = { url: newDb.settings.imgCodeUrl || global.imgCode.url };
  global.ktpCode = { url: newDb.settings.ktpUrl || '' };
}