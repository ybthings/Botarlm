//================================//
// Main
//================================//
global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['6282147570157']
global.cd = '300'; // 300 detik cooldown
global.linkOwner = "https://wa.me/6283163221894"
global.code = "code"  
// config/global.js

global.imgCode = { 

  url: 'https://raw.githubusercontent.com/ybthings/Pwsc/refs/heads/main/file_00000000ece461f98597f1297d6d24a6.png' 

}// default awal
//================================//
//================================//
// Global Mess
//================================//
global.menuMode = global.menuMode || {};
global.mess = {
 owner: '*You are not the owner*',
 premium: '*You are not premium*',
 group: '*This feature is for groups only*'
}