const fs = require('fs');
const { loadJsonData, saveJsonData } = require('../lib/function');
const settings = require('../config.js');

const OWNER_ID = settings.ownerId;
const OWNER_FILE = './db/users/adminID.json';

const OWNERP_FILE = './db/users/ownerID.json';
const PREMIUM_FILE = './db/users/premiumUsers.json';
const RESS_FILE = './db/users/resellerUsers.json';
const RESSVPS_FILE = './db/users/resellerVps.json';
const BUYERVPS_FILE = './db/users/buyerVps.json';

module.exports = (bot) => {
// command /addprem
bot.onText(/^\/addprem(?:\s+(\d+))?$/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const owners = loadJsonData(OWNERP_FILE);
    if (msg.from.id !== OWNER_ID && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ᴘᴀɴᴇʟ');
    }

    let targetUserId;

    if (match[1]) {
        // kalau pakai ID di command
        targetUserId = match[1];
    } else if (msg.reply_to_message) {
        // kalau reply pesan
        targetUserId = msg.reply_to_message.from.id.toString();
    } else {
        return bot.sendMessage(chatId, '❌ Reply ke pesan user!\nContoh:\n/addprem id');
    }

    const premUsers = loadJsonData(PREMIUM_FILE);

    if (!premUsers.includes(targetUserId)) {
        premUsers.push(targetUserId);
        saveJsonData(PREMIUM_FILE, premUsers);
        return bot.sendMessage(chatId, `✅ User ID ${targetUserId} berhasil ditambahkan sebagai Premium!`, {
            parse_mode: "Markdown",
            reply_to_message_id: msg.message_id
        });
    } else {
        return bot.sendMessage(chatId, `⚠️ User ID ${targetUserId} sudah menjadi Premium!`);
    }
});

// command /address
bot.onText(/^\/address(?:\s+(\d+))?$/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();

    const owners = loadJsonData(OWNERP_FILE);
    if (msg.from.id !== OWNER_ID && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ᴘᴀɴᴇʟ');
    }

    let targetUserId;

    if (match[1]) {
        targetUserId = match[1];
    } else if (msg.reply_to_message) {
        targetUserId = msg.reply_to_message.from.id.toString();
    } else {
        return bot.sendMessage(chatId, '❌ Reply ke pesan user!\nContoh:\n/address id');
    }

    const ressUsers = loadJsonData(RESS_FILE);

    if (!ressUsers.includes(targetUserId)) {
        ressUsers.push(targetUserId);
        saveJsonData(RESS_FILE, ressUsers);
        return bot.sendMessage(chatId, `✅ User ID ${targetUserId} berhasil ditambahkan sebagai Reseller Panel!`, {
            parse_mode: "Markdown",
            reply_to_message_id: msg.message_id
        });
    } else {
        return bot.sendMessage(chatId, `⚠️ User ID ${targetUserId} sudah menjadi Reseller Panel!`);
    }
});
 
// command /addpublic
bot.onText(/^\/addpublic(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const targetId = match[1];

  if (!targetId) {
    return bot.sendMessage(chatId, '❌ Format salah!\nContoh:\n/addpublic 123456789');
  }

  const owners = loadJsonData(OWNER_FILE);
  if (msg.from.id !== OWNER_ID && !owners.includes(msg.from.id)) {
    return bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
  }

  try {
    // cek apakah target bisa diakses
    const targetUser = await bot.getChat(targetId).catch(() => null);
    if (!targetUser) {
      return bot.sendMessage(chatId, '❌ User tidak ditemukan atau bot belum pernah chat dengan user tersebut.');
    }

    const ownerData = loadJsonData("./db/users/ownerID.json");
    const premiumData = loadJsonData("./db/users/premiumUsers.json");
    const resellerData = loadJsonData("./db/users/resellerUsers.json");

    const ownerMark = ownerData.includes(targetId) ? "✅" : "❌";
    const premiumMark = premiumData.includes(targetId) ? "✅" : "❌";
    const resellerMark = resellerData.includes(targetId) ? "✅" : "❌";

    const textMsg = `Username: @${targetUser.username || '-'}\nID: \`${targetId}\`\nType: User Public`;

    await bot.sendMessage(chatId, textMsg, {
      parse_mode: "Markdown",
      reply_to_message_id: msg.message_id,
      reply_markup: {
        inline_keyboard: [
          [
            { text: `ᴏᴡɴᴇʀ ${ownerMark}`, callback_data: `toggle_owner:${targetId}` }
          ],
          [
            { text: `ᴘʀᴇᴍɪᴜᴍ ${premiumMark}`, callback_data: `toggle_premium:${targetId}` },
            { text: `ʀᴇꜱᴇʟʟᴇʀ ${resellerMark}`, callback_data: `toggle_reseller:${targetId}` }
          ]
        ]
      }
    });
  } catch (err) {
    console.error("Error di /addpublic:", err.message);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan.");
  }
});

bot.on("callback_query", async (query) => {
  const chatId = query.message.chat.id;
  const messageId = query.message.message_id;
  const [action, targetId] = query.data.split(":");
    
  const owners = loadJsonData(OWNER_FILE);

if (!owners.includes(query.from.id.toString())) {
  return
}

  let filePath, label;
  if (action === "toggle_owner") {
    filePath = "./db/users/ownerID.json"; label = "ᴏᴡɴᴇʀ";
  }
  if (action === "toggle_premium") {
    filePath = "./db/users/premiumUsers.json"; label = "ᴘʀᴇᴍɪᴜᴍ";
  }
  if (action === "toggle_reseller") {
    filePath = "./db/users/resellerUsers.json"; label = "ʀᴇꜱᴇʟʟᴇʀ";
  }
  if (!filePath) return;

  try {
    let json = loadJsonData(filePath);
    let updated;

    if (json.includes(targetId)) {
      json = json.filter(id => id !== targetId); // hapus
      updated = `❌ User ID ${targetId} dihapus dari ${label}`;
    } else {
      json.push(targetId); // tambah
      updated = `✅ User ID ${targetId} ditambahkan ke ${label}`;
    }
    saveJsonData(filePath, json);

    // cek ulang semua file buat update status
    const ownerData = loadJsonData("./db/users/ownerID.json");
    const premiumData = loadJsonData("./db/users/premiumUsers.json");
    const resellerData = loadJsonData("./db/users/resellerUsers.json");

    const ownerMark = ownerData.includes(targetId) ? "✅" : "❌";
    const premiumMark = premiumData.includes(targetId) ? "✅" : "❌";
    const resellerMark = resellerData.includes(targetId) ? "✅" : "❌";

    const keyboard = [
      [
        { text: `ᴏᴡɴᴇʀ ${ownerMark}`, callback_data: `toggle_owner:${targetId}` }],
        [{ text: `ᴘʀᴇᴍɪᴜᴍ ${premiumMark}`, callback_data: `toggle_premium:${targetId}` },
        { text: `ʀᴇꜱᴇʟʟᴇʀ ${resellerMark}`, callback_data: `toggle_reseller:${targetId}` }
      ]
    ];

    await bot.editMessageReplyMarkup(
      { inline_keyboard: keyboard },
      { chat_id: chatId, message_id: messageId }
    );

    bot.answerCallbackQuery(query.id, { text: updated });
  } catch (err) {
    console.error(err);
    bot.answerCallbackQuery(query.id, { text: "❌ Error saat update user!" });
  }
});
    
// command /addpriv
bot.onText(/^\/addpriv(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const targetId = match[1];
    
    if (!targetId) {
        bot.sendMessage(chatId, '❌ Format salah!\nContoh:\n/addpriv 123456789');
        return;
    }
    
  const owners = loadJsonData(OWNER_FILE);
    if (msg.from.id !== OWNER_ID && !owners.includes(msg.from.id)) {
        return bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }

  const ownerPriv = loadJsonData("./db/users/private/privateID.json");
  const premiumPriv = loadJsonData("./db/users/private/privPrem.json");
  const resellerPriv = loadJsonData("./db/users/private/privRess.json");

  const ownerCheck = ownerPriv.includes(targetId) ? "✅" : "❌";
  const premiumCheck = premiumPriv.includes(targetId) ? "✅" : "❌";
  const resellerCheck = resellerPriv.includes(targetId) ? "✅" : "❌";

  const targetUser = await bot.getChat(targetId);

const textMsg = `Username: @${targetUser.username || '-'}
ID: \`${targetId}\`
Type: User Private`;

bot.sendMessage(chatId, textMsg, {
    parse_mode: "Markdown",
    reply_to_message_id: msg.message_id,
    reply_markup: {
      inline_keyboard: [
        [
          { text: `ᴏᴡɴᴇʀ ${ownerCheck}`, callback_data: `private_owner:${targetId}` }],
          [{ text: `ᴘʀᴇᴍɪᴜᴍ ${premiumCheck}`, callback_data: `private_premium:${targetId}` },
          { text: `ʀᴇꜱᴇʟʟᴇʀ ${resellerCheck}`, callback_data: `private_reseller:${targetId}` }
        ]
      ]
    }
  });
});

bot.on("callback_query", async (query) => {
  const chatId = query.message.chat.id;
  const messageId = query.message.message_id;
  const [action, targetId] = query.data.split(":");
    
  const owners = loadJsonData(OWNER_FILE);

if (!owners.includes(query.from.id.toString())) {
  return
}

  let filePath, label;
  if (action === "private_owner") {
    filePath = "./db/users/private/privateID.json"; label = "ᴏᴡɴᴇʀ";
  }
  if (action === "private_premium") {
    filePath = "./db/users/private/privatePrem.json"; label = "ᴘʀᴇᴍɪᴜᴍ";
  }
  if (action === "private_reseller") {
    filePath = "./db/users/private/privateRess.json"; label = "ʀᴇꜱᴇʟʟᴇʀ";
  }
  if (!filePath) return;

  try {
    let json = loadJsonData(filePath);
    let updated;

    if (json.includes(targetId)) {
      json = json.filter(id => id !== targetId); // hapus
      updated = `❌ User ID ${targetId} dihapus dari ${label}`;
    } else {
      json.push(targetId); // tambah
      updated = `✅ User ID ${targetId} ditambahkan ke ${label}`;
    }
    saveJsonData(filePath, json);

    // cek ulang semua file buat update status
    const ownerPriv = loadJsonData("./db/users/private/privateID.json");
    const premiumPriv = loadJsonData("./db/users/private/privatePrem.json");
    const resellerPriv = loadJsonData("./db/users/private/privateRess.json");

    const ownerCheck = ownerPriv.includes(targetId) ? "✅" : "❌";
    const premiumCheck = premiumPriv.includes(targetId) ? "✅" : "❌";
    const resellerCheck = resellerPriv.includes(targetId) ? "✅" : "❌";

    const keyboard = [
      [
        { text: `ᴏᴡɴᴇʀ ${ownerCheck}`, callback_data: `private_owner:${targetId}` }],
        [{ text: `ᴘʀᴇᴍɪᴜᴍ ${premiumCheck}`, callback_data: `private_premium:${targetId}` },
        { text: `ʀᴇꜱᴇʟʟᴇʀ ${resellerCheck}`, callback_data: `private_reseller:${targetId}` }
      ]
    ];

    await bot.editMessageReplyMarkup(
      { inline_keyboard: keyboard },
      { chat_id: chatId, message_id: messageId }
    );

    bot.answerCallbackQuery(query.id, { text: updated });
  } catch (err) {
    console.error(err);
    bot.answerCallbackQuery(query.id, { text: "❌ Error saat update user!" });
  }
});

// command /addrvps
bot.onText(/^\/addrvps(?:\s+(.+))?$/, (msg, match) => { 
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    // cek owner
    const owners = loadJsonData(OWNER_FILE);
    if (msg.from.id !== OWNER_ID && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }
    
    const text = match[1];
    if (!text) {
        bot.sendMessage(chatId, '❌ Format salah!\nContoh: /addrvps 123456789');
        return;
    }

    const targetUserId = match[1].trim();

    // validasi id
    if (!/^\d+$/.test(targetUserId)) {
        return bot.sendMessage(chatId, '❌ User ID harus berupa angka!');
    }

    // load file
    const ressVps = loadJsonData(RESSVPS_FILE);

    let addedRessVps = false;
    
    // tambahkan ke owner
    if (!ressVps.includes(targetUserId)) {
        ressVps.push(targetUserId);
        saveJsonData(RESSVPS_FILE, ressVps);
        addedRessVps = true;
    }

    if (addedRessVps) {
        bot.sendMessage(chatId, `✅ User ID ${targetUserId} berhasil ditambahkan sebagai Reseller VPS!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    } else {
        bot.sendMessage(chatId, `⚠️ User ID ${targetUserId} sudah menjadi Reseller VPS!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    }
});
    
// command /addbvps
bot.onText(/^\/addbvps(?:\s+(.+))?$/, (msg, match) => { 
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    // cek owner
    const owners = loadJsonData(OWNER_FILE);
    if (msg.from.id !== OWNER_ID && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }
    
    const text = match[1];
    if (!text) {
        bot.sendMessage(chatId, '❌ Format salah!\nContoh:\n/addbvps 123456789');
        return;
    }

    const targetUserId = match[1].trim();

    // validasi id
    if (!/^\d+$/.test(targetUserId)) {
        return bot.sendMessage(chatId, '❌ User ID harus berupa angka!');
    }

    // load file
    const buyerVps = loadJsonData(BUYERVPS_FILE);

    let addedBuyVps = false;
    
    // tambahkan ke owner
    if (!buyerVps.includes(targetUserId)) {
        buyerVps.push(targetUserId);
        saveJsonData(BUYERVPS_FILE, buyerVps);
        addedBuyVps = true;
    }

    if (addedBuyVps) {
        bot.sendMessage(chatId, `✅ User ID ${targetUserId} berhasil ditambahkan sebagai Buyer VPS!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    } else {
        bot.sendMessage(chatId, `⚠️ User ID ${targetUserId} sudah menjadi Buyer VPS!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    }
});
    
// command /addtk
bot.onText(/^\/addtk(?:\s+(.+))?$/, (msg, match) => { 
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    // cek owner
    const owners = loadJsonData(OWNER_FILE);
    if (msg.from.id !== OWNER_ID && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }
    
    const text = match[1];
    if (!text) {
        bot.sendMessage(chatId, '❌ Format salah!\nContoh: /addtk 123456789');
        return;
    }

    const targetUserId = match[1].trim();

    // validasi id
    if (!/^\d+$/.test(targetUserId)) {
        return bot.sendMessage(chatId, '❌ User ID harus berupa angka!');
    }

    // load file
    const premiumUsers = loadJsonData(PREMIUM_FILE);
    const ressUsers = loadJsonData(RESS_FILE);
    const ownerUsers = loadJsonData(OWNER_FILE);

    let addedPrem = false;
    let addedRes = false;
    let addedOwner = false;

    // tambahkan ke premium
    if (!premiumUsers.includes(targetUserId)) {
        premiumUsers.push(targetUserId);
        saveJsonData(PREMIUM_FILE, premiumUsers);
        addedPrem = true;
    }

    // tambahkan ke reseller
    if (!ressUsers.includes(targetUserId)) {
        ressUsers.push(targetUserId);
        saveJsonData(RESS_FILE, ressUsers);
        addedRes = true;
    }
    
    // tambahkan ke owner
    if (!ownerUsers.includes(targetUserId)) {
        ownerUsers.push(targetUserId);
        saveJsonData(OWNER_FILE, ownerUsers);
        addedOwner = true;
    }

    if (addedPrem || addedRes || addedOwner) {
        bot.sendMessage(chatId, `✅ User ID ${targetUserId} berhasil ditambahkan sebagai Tangan Kanan Panel!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    } else {
        bot.sendMessage(chatId, `⚠️ User ID ${targetUserId} sudah menjadi Tangan Kanan Panel!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    }
});

// command /addpt
bot.onText(/^\/addpt(?:\s+(.+))?$/, (msg, match) => { 
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    // cek owner
    const owners = loadJsonData(OWNER_FILE);
    if (msg.from.id !== OWNER_ID && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }
    
    const text = match[1];
    if (!text) {
        bot.sendMessage(chatId, '❌ Format salah!\nContoh: /addpt 123456789');
        return;
    }

    const targetUserId = match[1].trim();

    // validasi id
    if (!/^\d+$/.test(targetUserId)) {
        return bot.sendMessage(chatId, '❌ User ID harus berupa angka!');
    }

    // load file
    const premiumUsers = loadJsonData(PREMIUM_FILE);
    const ressUsers = loadJsonData(RESS_FILE);
    const ownerUsers = loadJsonData(OWNER_FILE);

    let addedPrem = false;
    let addedRes = false;
    let addedOwner = false;

    // tambahkan ke premium
    if (!premiumUsers.includes(targetUserId)) {
        premiumUsers.push(targetUserId);
        saveJsonData(PREMIUM_FILE, premiumUsers);
        addedPrem = true;
    }

    // tambahkan ke reseller
    if (!ressUsers.includes(targetUserId)) {
        ressUsers.push(targetUserId);
        saveJsonData(RESS_FILE, ressUsers);
        addedRes = true;
    }
    
    // tambahkan ke owner
    if (!ownerUsers.includes(targetUserId)) {
        ownerUsers.push(targetUserId);
        saveJsonData(OWNER_FILE, ownerUsers);
        addedOwner = true;
    }

    if (addedPrem || addedRes || addedOwner) {
        bot.sendMessage(chatId, `✅ User ID ${targetUserId} berhasil ditambahkan sebagai Partner Panel`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    } else {
        bot.sendMessage(chatId, `⚠️ User ID ${targetUserId} sudah menjadi Partner Panel!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    }
});

// command /addown panel
bot.onText(/^\/addown(?:\s+(.+))?$/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    // cek owner
    const owners = loadJsonData(OWNERP_FILE);
    if (msg.from.id !== OWNER_ID && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ᴘᴀɴᴇʟ');
    }

    const text = match[1];
    if (!text) {
        bot.sendMessage(chatId, '❌ Format salah!\nContoh:\n/addown 123456789');
        return;
    }
    
    const targetUserId = match[1].trim();

    // validasi id
    if (!/^\d+$/.test(targetUserId)) {
        return bot.sendMessage(chatId, '❌ User ID harus berupa angka!');
    }

    // load file
    const premiumUsers = loadJsonData(PREMIUM_FILE);
    const ressUsers = loadJsonData(RESS_FILE);
    const ownerpUsers = loadJsonData(OWNERP_FILE);

    let addedPrem = false;
    let addedRes = false;
    let addedOwnerP = false;

    // tambahkan ke premium
    if (!premiumUsers.includes(targetUserId)) {
        premiumUsers.push(targetUserId);
        saveJsonData(PREMIUM_FILE, premiumUsers);
        addedPrem = true;
    }

    // tambahkan ke reseller
    if (!ressUsers.includes(targetUserId)) {
        ressUsers.push(targetUserId);
        saveJsonData(RESS_FILE, ressUsers);
        addedRes = true;
    }
    
    // tambahkan ke owner
    if (!ownerpUsers.includes(targetUserId)) {
        ownerpUsers.push(targetUserId);
        saveJsonData(OWNERP_FILE, ownerpUsers);
        addedOwnerP = true;
    }

    if (addedPrem || addedRes || addedOwnerP) {
        bot.sendMessage(chatId, `✅ User ID ${targetUserId} berhasil ditambahkan sebagai Owner Panel!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    } else {
        bot.sendMessage(chatId, `⚠️ User ID ${targetUserId} sudah menjadi Owner Panel!`);
    }
});
    
// command add premium & reseller
bot.onText(/^\/addpr (.+)$/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    // cek owner
    const owners = loadJsonData(OWNERP_FILE);
    if (msg.from.id !== OWNER_ID && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '❌ ᴋʜᴜsᴜs ᴏᴡɴᴇʀ');
    }

    const text = match[1];
    if (!text) {
        bot.sendMessage(chatId, '❌ Format salah!\nContoh: /addpr 123456789');
        return;
    }
    
    const targetUserId = match[1].trim();

    // validasi id
    if (!/^\d+$/.test(targetUserId)) {
        return bot.sendMessage(chatId, '❌ User ID harus berupa angka!');
    }

    // load file
    const premiumUsers = loadJsonData(PREMIUM_FILE);
    const ressUsers = loadJsonData(RESS_FILE);

    let addedPrem = false;
    let addedRes = false;

    // tambahkan ke premium
    if (!premiumUsers.includes(targetUserId)) {
        premiumUsers.push(targetUserId);
        saveJsonData(PREMIUM_FILE, premiumUsers);
        addedPrem = true;
    }

    // tambahkan ke reseller
    if (!ressUsers.includes(targetUserId)) {
        ressUsers.push(targetUserId);
        saveJsonData(RESS_FILE, ressUsers);
        addedRes = true;
    }

    if (addedPrem || addedRes) {
        bot.sendMessage(chatId, `✅ User ID ${targetUserId} berhasil ditambahkan menjadi Premium & Reseller`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    } else {
        bot.sendMessage(chatId, `⚠️ ᴜꜱᴇʀ ${targetUserId} ꜱᴜᴅᴀʜ ᴍᴇɴᴊᴀᴅɪ ᴘʀᴇᴍɪᴜᴍ ᴅᴀɴ ʀᴇꜱᴇʟʟᴇʀ!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    }
});
    
}